

USE master;
GO

-- Eliminar si existe
IF EXISTS (SELECT name FROM sys.databases WHERE name = 'LaglaVet')
BEGIN
    ALTER DATABASE LaglaVet SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE LaglaVet;
END
GO

-- Crear base de datos
CREATE DATABASE LaglaVet
    COLLATE Latin1_General_CI_AS;
GO

USE LaglaVet;
GO

-- ========================================
-- TABLA: USUARIOS
-- ========================================
CREATE TABLE usuarios (
    id_usuario INT IDENTITY(1,1) PRIMARY KEY,
    username NVARCHAR(50) NOT NULL UNIQUE,
    password NVARCHAR(255) NOT NULL,
    nombre_completo NVARCHAR(100) NOT NULL,
    rol NVARCHAR(10) NOT NULL CHECK (rol IN ('ADMIN', 'RECEP', 'VET')),
    activo BIT DEFAULT 1
);
CREATE INDEX idx_username ON usuarios(username);
CREATE INDEX idx_rol ON usuarios(rol);
GO

INSERT INTO usuarios (username, password, nombre_completo, rol, activo) VALUES
('admin1', 'admin123', 'Administrador General', 'ADMIN', 1),
('vet1', 'vet123', 'Dr. Carlos Veterinario', 'VET', 1),
('recep1', 'recep123', 'Ana Recepci�n', 'RECEP', 1);
GO

-- ========================================
-- TABLA: MASCOTAS
-- ========================================
CREATE TABLE mascotas (
    id_mascota INT IDENTITY(1,1) PRIMARY KEY,
    nombre_mascota NVARCHAR(50) NOT NULL,
    especie NVARCHAR(20) NOT NULL CHECK (especie IN ('Perro', 'Gato', 'Otro')),
    raza NVARCHAR(50),
    nombre_dueno NVARCHAR(100) NOT NULL,
    telefono NVARCHAR(20) NOT NULL
);
CREATE INDEX idx_nombre_mascota ON mascotas(nombre_mascota);
CREATE INDEX idx_dueno ON mascotas(nombre_dueno);
GO

INSERT INTO mascotas (nombre_mascota, especie, raza, nombre_dueno, telefono) VALUES
('Firulais', 'Perro', 'Criollo', 'Juan P�rez', '0987654321'),
('Mishi', 'Gato', 'Angora', 'Mar�a L�pez', '0912345678'),
('Bobby', 'Perro', 'Golden', 'Luis Chamba', '0999999999');
GO

-- ========================================
-- TABLA: DOCTORES
-- ========================================
CREATE TABLE doctores (
    id_doctor INT IDENTITY(1,1) PRIMARY KEY,
    nombre_doctor NVARCHAR(100) NOT NULL,
    especialidad NVARCHAR(100) NOT NULL,
    disponible BIT DEFAULT 1
);
CREATE INDEX idx_nombre_doctor ON doctores(nombre_doctor);
CREATE INDEX idx_disponible ON doctores(disponible);
GO

INSERT INTO doctores (nombre_doctor, especialidad, disponible) VALUES
('Dr. Carlos Veterinario', 'Cirug�a y vacunas', 1),
('Dra. Andrea Salas', 'Odontolog�a felina', 0);
GO

-- ========================================
-- TABLA: SERVICIOS
-- ========================================
CREATE TABLE servicios (
    id_servicio INT IDENTITY(1,1) PRIMARY KEY,
    nombre_servicio NVARCHAR(100) NOT NULL,
    categoria NVARCHAR(30) NOT NULL CHECK (categoria IN ('Cirug�a', 'Odontolog�a', 'Vacunaci�n', 'Consulta', 'Otro')),
    doctor_responsable NVARCHAR(100),
    precio DECIMAL(8,2) NOT NULL,
    duracion_estim NVARCHAR(20)
);
GO

INSERT INTO servicios (nombre_servicio, categoria, doctor_responsable, precio, duracion_estim) VALUES
('Esterilizaci�n (perro)', 'Cirug�a', 'Dr. Carlos Veterinario', 120.00, '45 min'),
('Limpieza dental felina', 'Odontolog�a', 'Dra. Andrea Salas', 60.00, '30 min'),
('Vacuna antirr�bica', 'Vacunaci�n', 'Dr. Carlos Veterinario', 18.00, '10 min');
GO

-- ========================================
-- TABLA: PRODUCTOS
-- ========================================
CREATE TABLE productos (
    id_producto INT IDENTITY(1,1) PRIMARY KEY,
    nombre_producto NVARCHAR(100) NOT NULL,
    categoria NVARCHAR(30) NOT NULL CHECK (categoria IN ('Medicamento', 'Alimento', 'Accesorio', 'Otro')),
    stock INT NOT NULL DEFAULT 0,
    precio DECIMAL(8,2) NOT NULL
);
CREATE INDEX idx_categoria ON productos(categoria);
CREATE INDEX idx_stock ON productos(stock);
GO

INSERT INTO productos (nombre_producto, categoria, stock, precio) VALUES
('Antipulgas NexGard 10-25kg', 'Medicamento', 12, 22.50),
('Alimento Premium cachorro 2kg', 'Alimento', 5, 15.99),
('Collar isabelino ajustable', 'Accesorio', 2, 8.00);
GO

-- ========================================
-- TABLA: CITAS
-- ========================================
CREATE TABLE citas (
    id_cita INT IDENTITY(1,1) PRIMARY KEY,
    id_mascota INT NOT NULL,
    id_doctor INT NOT NULL,
    fecha_hora DATETIME NOT NULL,
    motivo NVARCHAR(255),
    estado NVARCHAR(15) DEFAULT 'PENDIENTE' CHECK (estado IN ('PENDIENTE', 'ATENDIDA', 'CANCELADA')),
    CONSTRAINT FK_citas_mascota FOREIGN KEY (id_mascota) REFERENCES mascotas(id_mascota) ON DELETE CASCADE,
    CONSTRAINT FK_citas_doctor FOREIGN KEY (id_doctor) REFERENCES doctores(id_doctor)
);
CREATE INDEX idx_fecha_hora ON citas(fecha_hora);
CREATE INDEX idx_estado ON citas(estado);
GO

INSERT INTO citas (id_cita, id_mascota, id_doctor, fecha_hora, motivo, estado) VALUES
(10, 1, 1, '2025-10-30 09:00:00', 'Vacuna anual', 'PENDIENTE'),
(11, 2, 1, '2025-10-31 15:30:00', 'Revisi�n general', 'PENDIENTE'),
(12, 3, 1, '2025-10-31 18:00:00', 'Control post-cirug�a', 'ATENDIDA');
GO

-- ========================================
-- TABLA: HISTORIAL CL�NICO
-- ========================================
CREATE TABLE historial_clinico (
    id_historial INT IDENTITY(1,1) PRIMARY KEY,
    id_mascota INT NOT NULL,
    fecha DATE NOT NULL,
    detalle NVARCHAR(255) NOT NULL,
    doctor NVARCHAR(100) NOT NULL,
    CONSTRAINT FK_historial_mascota FOREIGN KEY (id_mascota) REFERENCES mascotas(id_mascota) ON DELETE CASCADE
);
CREATE INDEX idx_mascota_fecha ON historial_clinico(id_mascota, fecha);
GO

INSERT INTO historial_clinico (id_mascota, fecha, detalle, doctor) VALUES
(1, '2025-10-15', 'Vacuna parvovirus', 'Dr. Carlos'),
(1, '2025-10-30', 'Vacuna anual', 'Dr. Carlos'),
(2, '2025-10-20', 'Limpieza dental', 'Dra. Andrea');
GO

PRINT 'Base de datos LaglaVet creada con �xito!';
GO

SELECT * FROM dbo.usuarios;


-- Tabla facturas (ventas)
CREATE TABLE facturas (
    id_factura INT IDENTITY(1,1) PRIMARY KEY,
    id_usuario INT NOT NULL,
    fecha DATETIME DEFAULT GETDATE(),
    total DECIMAL(8,2) NOT NULL,
    CONSTRAINT FK_facturas_usuario FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
);

-- Detalle facturas (items vendidos)
CREATE TABLE facturas_detalle (
    id_detalle INT IDENTITY(1,1) PRIMARY KEY,
    id_factura INT NOT NULL,
    id_producto INT NOT NULL,
    cantidad INT NOT NULL,
    precio_unitario DECIMAL(8,2) NOT NULL,
    CONSTRAINT FK_detalle_factura FOREIGN KEY (id_factura) REFERENCES facturas(id_factura),
    CONSTRAINT FK_detalle_producto FOREIGN KEY (id_producto) REFERENCES productos(id_producto)
);

-- Hash passwords existentes (ejecuta por cada usuario)
UPDATE usuarios SET password = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi' WHERE username = 'admin1';  -- Para 'password' temporal; cambia a real
-- Mejor: En PHP, usa un script para hashear y actualizar.

RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ index.php?url=$1 [QSA,L]